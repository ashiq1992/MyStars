
#include <iostream>
#include <stdio.h>
#include <string>



int main() {
	int choice, n;
	int i = 0;
	
	Mammal *mammals[10];
		

	cout << "Select the animal to send to Zoo (1)Dog (2)Cat (3)Lion (4)Move all animals (5) Quit:" << endl;
	cin >> choice;
	if (choice == 4) {
		cout << "No mammal selected." << endl;
		cout << "Program exiting ... " << endl;
		return 0;
	}

	else if (choice == 5) {
		cout << "Program exiting ... " << endl;
		return 0;
	}

	else {
		while (choice != 4) {

			switch (choice) {
			case 1: mammals[i] = new Dog();
				i++;
				break;
			case 2: mammals[i] = new Cat();
				i++;
				break;
			case 3: mammals[i] = new Lion();
				i++;
				break;
			case 5:
				for (n = 0; n<i; n++)  //clear pointer
					delete mammals[n];

				cout << "Program exiting ... " << endl;
				return 0;
			default: cout << "Invalid choice, enter again" << endl;
			}

			cout << "Select the animal to send to Zoo (1) Dog(2) Cat(3) Lion(4) Move all animals (5) Quit:" << endl;
			cin >> choice;

		}

	}

	for (n = 0; n < i; n++) {
		mammals[n]->move();
		mammals[n]->speak();
		mammals[n]->eat();
	}
	system("PAUSE");
	for (n = 0; n<i; n++)  //clear pointer
		delete mammals[n];

	cout << "Program exiting ... " << endl;
	return 0;

}