#include <iostream>
#include <iomanip>
#include "subAnimal.h"
class Cat :public subAnimal {
public:
	Cat() {
		cout << "constructing default Cat object " << endl;
	}
	void speak() const {
		cout << "Cats go Meow" << endl;
	}
	void move() const {
		cout << "Cats Walk" << endl;
	}
	~Cat() {
		cout << "destructing Cat object " << endl;
	}

};
