#include <iostream>
#include <iomanip>
#include "subAnimal.h"
class Dog : public subAnimal {
public:
	Dog() {
		cout << "constructing default Dog object " << endl;
	}

	Dog(string n, COLOR c, string own) {
		name = n;
		c1 = c;
		owner = own;
		cout << "constructing Dog with parameter object " << endl;
		//		Mammal(n, c);
	}

	~Dog() {
		cout << "destructing Dog object " << endl;
	}

	void speak() const {
		cout << "Dogs go Woof" << endl;
	}
	void move() const {
		cout << "Dogs Walk" << endl;
	}

private:
	string owner;
	string name;
	COLOR c1;
};