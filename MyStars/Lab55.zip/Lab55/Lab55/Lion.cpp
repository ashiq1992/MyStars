#include <iostream>
#include <iomanip>
#include "Mammals.h"
#include "subAnimal.h"

class Lion : public subAnimal {
public:
	Lion() {
		cout << "constructing default Lion object " << endl;
	}
	void speak() const {
		cout << "Lions go Roar" << endl;
	}
	void move() const {
		cout << "Lions Walk" << endl;
	}
	~Lion() {
		cout << "destructing Lion object " << endl;
	}

};