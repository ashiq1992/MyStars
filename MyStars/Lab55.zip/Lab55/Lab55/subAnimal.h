#include "Mammals.cpp"
#include "Mammals.h"
#include <String.h>


class subAnimal {
	class Lion :public Mammal {
	public:
		Lion() {

		}
		void speak() const {

		}
		void move() const {

		}
		~Lion() {

		}

	};
	class Dog : public Mammal {
	public:
		Dog() {

		}

		Dog(string n, COLOR c, string own) {

		}

		~Dog() {

		}

		void speak() const {

		}
		void move() const {

		}

	private:
		string owner;
		string name;
		COLOR c1;
	};




	class Cat :public Mammal {
	public:
		Cat() {

		}
		void speak() const {

		}
		void move() const {

		}
		~Cat() {

		}

	};


}


#pragma once
