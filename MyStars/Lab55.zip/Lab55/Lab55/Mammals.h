#include "stdafx.h"
#include "stdio.h"
#include <string>
enum COLOR { Green, Blue, White, Black, Brown };
#include <iostream>
#include <string>
using namespace std;
class Animal {
private:
	int hour;
	string _name;
	COLOR _color;

public:
	Animal() : _name("unknown");
	
	Animal(string n, COLOR c);
	
	
	~Animal();


	virtual void speak() const;
	
	virtual void move() const = 0;
};


class Mammal : Animal {
	private:
	string name;
	COLOR c1;
public:
	Mammal();
	Mammal(string n, COLOR c);
	void eat() const;
		~Mammal();

		virtual void move() const;

};
#pragma once
