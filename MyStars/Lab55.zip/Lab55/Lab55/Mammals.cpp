#include <iostream>
#include <iomanip>
#include "Mammals.h"
class Mammal : Animal{

public:
	Mammal() {
		cout << "constructing default Mammal object " << endl;
	}
	Mammal(string n, COLOR c) {
		name = n;
		c1 = c;
		cout << "constructing Mammal with parameter object " << endl;
	}
	void eat() const {
		cout << "Mammal eat " << endl;
	}
	~Mammal() {
		cout << "destructing Mammal object " << name << endl;
	}

	virtual void move() const {
		cout << "move() in Mammal class" << endl;
	}
private:
	string name;
	COLOR c1;
};